package com.userdb.dto;

import com.userdb.model.Login;

public class Loginservices {


public static  Login getLoginDetails(String username){
	Login login=new Login();
	login.setUsername(login.getUsername());
	login.setPassword(username);
	return login; 
}
}