package com.userdb.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class DbConnection {
	private static Connection con=null;
	
	String var="myDS";
	public static Connection getConnection(){
		
		try{
		Class.forName("com.mysql.jdbc.Driver");
		
		}catch(ClassNotFoundException e){
			e.printStackTrace();
			System.out.println("mysql class driver not loaded");
		}
		try{
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/userdb", "root", "root");
		}catch(SQLException e){
			e.printStackTrace();
			System.out.println("connection failed");
		}
		System.out.println(con);
		return con;
	}
}
