package com.userdb.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.omg.CORBA.Request;

import com.userdb.dao.UserDAO;
import com.userdb.dto.Loginservices;
import com.userdb.model.Admin;
import com.userdb.model.Adminaccess;
import com.userdb.model.Login;
import com.userdb.model.Register;
import com.userdb.model.StudentPlacements;

public class UserServlet extends HttpServlet {
	

    private UserDAO dao;
	public UserServlet() {
		dao = new UserDAO();
	}

	public RequestDispatcher dispatcher = null;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		new UserServlet();
		HttpSession session = req.getSession();
		String path = req.getServletPath();
		System.out.println(path);
		if (path.equals("/login.do")) {
			Login login = new Login();
			String user = req.getParameter("username");
			login.setUsername(user);
			login.setPassword(req.getParameter("password"));

			// UserDAO dao = new UserDAO();
			int x = dao.userLogin(login);
			if (x == 1) {
				login = Loginservices.getLoginDetails(user);
				req.getSession().setAttribute("user", login);
				dispatcher = req.getRequestDispatcher("Home.jsp");
				dispatcher.forward(req, resp);
			} else {
				dispatcher = req.getRequestDispatcher("error.jsp");
				dispatcher.forward(req, resp);
			}

		} else if (path.equals("/register.do")) {

			Register register = new Register();
			register.setName(req.getParameter("name"));
			register.setFathername(req.getParameter("fathername"));
			register.setUsername(req.getParameter("username"));
			register.setPassword(req.getParameter("password"));
			register.setMobile(req.getParameter("mobile"));
			register.setEmail(req.getParameter("email"));
			boolean b;
			try {
				b = dao.registerUser(register);

				if (b == true) {
					session.setAttribute("regform", register);
					dispatcher = req.getRequestDispatcher("registersuccess.jsp");
					dispatcher.forward(req, resp);
				} else {
					dispatcher = req.getRequestDispatcher("error.jsp");
					dispatcher.forward(req, resp);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (path.equals("/delete.do")) {

			int id = Integer.parseInt(req.getParameter("id"));
			boolean b = dao.deletePlacedStudent(id);
			if (b) {
				dispatcher = req.getRequestDispatcher("Adminuse.jsp");
				dispatcher.forward(req, resp);
			} else {
				dispatcher = req.getRequestDispatcher("error.jsp");
				dispatcher.forward(req, resp);
			}
		} else if (path.equals("/admin.do")) {
			Admin admin = new Admin();
			admin.setUsername(req.getParameter("username"));
			admin.setPassword(req.getParameter("password"));

			// UserDAO dao = new UserDAO();
			int x = dao.userAdmin(admin);
			if (x == 1) {

				session.setAttribute("user", admin);
				dispatcher = req.getRequestDispatcher("Adminaccess.jsp");
				dispatcher.forward(req, resp);
			} else {
				dispatcher = req.getRequestDispatcher("error.jsp");
				dispatcher.forward(req, resp);
			}
		} else if (path.equals("/adminaccess.do")) {

			StudentPlacements student = new StudentPlacements();
			student.setId(Integer.parseInt(req.getParameter("id")));
			student.setName(req.getParameter("name"));
			student.setEducation(req.getParameter("education"));
			student.setStream(req.getParameter("stream"));
			student.setScore(Integer.parseInt(req.getParameter("score")));
			student.setCompanyname(req.getParameter("companyname"));
			student.setYop(Integer.parseInt(req.getParameter("yop")));
			student.setContactno(Integer.parseInt(req.getParameter("contactno")));
			boolean b;
			try {
				b = dao.PlacedStudents(student);

				if (b == true) {
					session.setAttribute("placedStudent", student);
					dispatcher = req.getRequestDispatcher("Adminuse.jsp");
					dispatcher.forward(req, resp);
				} else {
					dispatcher = req.getRequestDispatcher("error.jsp");
					dispatcher.forward(req, resp);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (path.equals("/register.do")) {

			Register register = new Register();
			register.setName(req.getParameter("name"));
			register.setFathername(req.getParameter("fathername"));
			register.setUsername(req.getParameter("username"));
			register.setPassword(req.getParameter("password"));
			register.setMobile(req.getParameter("mobile"));
			register.setEmail(req.getParameter("email"));
			boolean b;
			try {
				b = dao.registerUser(register);

				if (b == true) {
					session.setAttribute("regform", register);
					dispatcher = req.getRequestDispatcher("registersuccess.jsp");
					dispatcher.forward(req, resp);
				} else {
					dispatcher = req.getRequestDispatcher("error.jsp");
					dispatcher.forward(req, resp);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String name = request.getParameter("name");
		String forward="";
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		StudentPlacements st=dao.getPlacedStudentById(id);
	

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/userdb", "root", "root");
			PreparedStatement ps = con.prepareStatement("select * from user where name=?");
			ps.setString(1, name);
			out.print("<center><table width=25% border=1>");
			out.print("<center><h1>Result:</h1></center>");
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				out.print("<tr>");
				out.print("<td> Name </td>");
				out.print("<td>" + rs.getString(1) + "</td></tr>");
				out.print("<tr><td>Fathername</td>");
				out.print("<td>" + rs.getString(2) + "</td></tr>");
				out.print("<tr><td>Username</td>");
				out.print("<td>" + rs.getString(3) + "</td></tr>");
				out.print("<tr><td>Password</td>");
				out.print("<td>" + rs.getString(4) + "</td></tr>");
				out.print("<tr><td>Mobile</td>");
				out.print("<td>" + rs.getString(5) + "</td></tr>");
				out.print("<tr><td>Email</td>");
				out.print("<td>" + rs.getString(6) + "</td></tr>");
			}
			out.print("</table></center>");

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			System.out.println("mysql class driver not loaded");

		}
	}
	
}
