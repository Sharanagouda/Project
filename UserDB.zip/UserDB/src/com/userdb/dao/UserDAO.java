package com.userdb.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.userdb.db.DbConnection;
import com.userdb.model.Admin;
import com.userdb.model.Adminaccess;
import com.userdb.model.Login;
import com.userdb.model.Register;
import com.userdb.model.StudentPlacements;

public class UserDAO {
	private Connection con = null;
	private Statement stmt = null;
	private PreparedStatement pstmt = null;
	private ResultSet resultSet = null;

	// for main page
	public int userLogin(Login login) {
		String query = "select * from user where username='" + login.getUsername() + "' and password = '"
				+ login.getPassword() + "'";
		System.out.println(query);
		int x = 0;
		con = DbConnection.getConnection();
		try {
			stmt = con.createStatement();
			resultSet = stmt.executeQuery(query);
			if (resultSet.next()) {
				x = 1;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return x;
	}

	// Registration for new users
	public boolean registerUser(Register register) throws SQLException {
		con = DbConnection.getConnection();
		boolean b = false;
		try {
			String query = "insert into user(name,fathername,username,password,mobile,email) values(?,?,?,?,?,?)";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, register.getName());
			pstmt.setString(2, register.getFathername());
			pstmt.setString(3, register.getUsername());
			pstmt.setString(4, register.getPassword());
			pstmt.setString(5, register.getMobile());
			pstmt.setString(6, register.getEmail());
			int x = pstmt.executeUpdate();
			pstmt.close();

			if (x == 1) {
				b = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return b;

	}

	// for Admin login
	public int userAdmin(Admin admin) {
		String query = "select * from user where username='" + admin.getUsername() + "' and password = '"
				+ admin.getPassword() + "'";
		System.out.println(query);
		int x = 0;
		con = DbConnection.getConnection();
		try {
			stmt = con.createStatement();
			resultSet = stmt.executeQuery(query);
			if (resultSet.next()) {
				x = 1;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return x;
	}

	// only for Admin use to Add placed Student in the list
	public boolean PlacedStudents(StudentPlacements student) throws SQLException {
		boolean c = false;
		con = DbConnection.getConnection();
		try {
			String query = "insert into placements(id,name,education,stream,score,companyname,yop,contactno) values (?,?,?,?,?,?,?,?)";
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, student.getId());
			pstmt.setString(2, student.getName());
			pstmt.setString(3, student.getEducation());
			pstmt.setString(4, student.getStream());
			pstmt.setInt(5, student.getScore());
			pstmt.setString(6, student.getCompanyname());
			pstmt.setInt(7, student.getYop());
			pstmt.setInt(8, student.getContactno());
			int x = pstmt.executeUpdate();
			pstmt.close();
			if (x == 1) {
				c = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return c;
	}

	// Get all the Placed Student List in the table
	public ArrayList<Adminaccess> GetAllStudent() throws SQLException {
		ArrayList<Adminaccess> arr = new ArrayList<>();
		String query = "SELECT id,name,education,stream,score,companyname,yop,contactno from placements";
		con = DbConnection.getConnection();
		try {
			pstmt = con.prepareStatement(query);
			resultSet = pstmt.executeQuery();
			while (resultSet.next()) {
				Adminaccess aa = new Adminaccess();
				aa.setId(resultSet.getInt("id"));
				aa.setName(resultSet.getString("name"));
				aa.setEducation(resultSet.getString("education"));
				aa.setStream(resultSet.getString("stream"));
				aa.setScore(resultSet.getInt("score"));
				aa.setCompanyname(resultSet.getString("companyname"));
				aa.setYop(resultSet.getInt("yop"));
				aa.setContactno(resultSet.getInt("contactno"));
				arr.add(aa);

			}
		} finally {

		}

		return arr;

	}

	// Get info about registed people
	public boolean GetPersonDetails(Register register) throws SQLException {
		con = DbConnection.getConnection();
		boolean b = false;
		try {
			String query = "SELECT name,fathername,username,password,mobile,email from user";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, register.getName());
			pstmt.setString(2, register.getFathername());
			pstmt.setString(3, register.getUsername());
			pstmt.setString(4, register.getPassword());
			pstmt.setString(5, register.getMobile());
			pstmt.setString(6, register.getEmail());
			int x = pstmt.executeUpdate();
			pstmt.close();

			if (x == 1) {
				b = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return b;
	}

	// delete the user
	public boolean deletePlacedStudent(int id) {
		boolean b = false;
		String query = "delete from placements where id='" + id + "'";
		con = DbConnection.getConnection();
		try {
			stmt = con.createStatement();
			int x = stmt.executeUpdate(query);
			if (x == 1) {
				b = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return b;
	}

	// Update PlacedStudentList
	public  StudentPlacements getPlacedStudentById(int id) {
		StudentPlacements st = new StudentPlacements();
		try {
			
			PreparedStatement pstmt = con.prepareStatement("select * from placements where id=?");
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			// Parameters start with 1
			if (rs.next()) {
				st.setId(rs.getInt(1));
				st.setName(rs.getString(2));
				st.setEducation(rs.getString(3));
				st.setStream(rs.getString(4));
				st.setScore(rs.getInt(5));
				st.setCompanyname(rs.getString(6));
				st.setYop(rs.getInt(7));
				st.setContactno(rs.getInt(8));
			}
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return st;
	}
}
