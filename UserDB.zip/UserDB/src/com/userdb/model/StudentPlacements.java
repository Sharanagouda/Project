package com.userdb.model;

public class StudentPlacements {
private int id,yop,contactno,score;
private String name,education,stream, companyname;



public int getId() {
	return id;
}



public void setId(int id) {
	this.id = id;
}



public int getYop() {
	return yop;
}



public void setYop(int yop) {
	this.yop = yop;
}



public int getContactno() {
	return contactno;
}



public void setContactno(int contactno) {
	this.contactno = contactno;
}



public int getScore() {
	return score;
}



public void setScore(int score) {
	this.score = score;
}



public String getName() {
	return name;
}



public void setName(String name) {
	this.name = name;
}



public String getEducation() {
	return education;
}



public void setEducation(String education) {
	this.education = education;
}



public String getStream() {
	return stream;
}



public void setStream(String stream) {
	this.stream = stream;
}



public String getCompanyname() {
	return companyname;
}



public void setCompanyname(String companyname) {
	this.companyname = companyname;
}



public StudentPlacements(){
	this.id=id;
	this.yop=yop;
	this.contactno=contactno;
	this.score=score;
	this.name=name;
	this.education=education;
	this.stream=stream;
	this.companyname=companyname;
}


}