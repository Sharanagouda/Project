package com.userdb.model;

public class Adminaccess {
private int id;
private String name;
private String education;
private String stream;
private int score;
private String companyname;
private int yop;
private int contactno;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEducation() {
	return education;
}
public void setEducation(String education) {
	this.education = education;
}
public String getStream() {
	return stream;
}
public void setStream(String stream) {
	this.stream = stream;
}
public int getScore() {
	return score;
}
public void setScore(int score) {
	this.score = score;
}
public String getCompanyname() {
	return companyname;
}
public void setCompanyname(String companyname) {
	this.companyname = companyname;
}
public int getYop() {
	return yop;
}
public void setYop(int yop) {
	this.yop = yop;
}
public int getContactno() {
	return contactno;
}
public void setContactno(int contactno) {
	this.contactno = contactno;
}


}